import Body from '@/components/Body';

export default function GeneratePage() {
  return <Body />;
}
